# Uyghur UI React example

Run npm install, then npm run dev. npm run build creates a static app. This portable copy installs both pinned v0.4.0 community GitHub release packages; npm registry publication of those packages is not required. React and Vite dependencies are fetched normally by npm.

Includes the writing field, explicit cleanup, controlled dialog/tabs, six cultural interactions and pause/reduced motion. All demo content stays in the browser. ALKATIP Basma fonts load from the supplied external URLs; font binaries are not bundled.

Source: https://github.com/UyghurCommunity/uyghur-ui/tree/main/packages/react/example
